import requests
import jwt

login = input("Do you have a token? (y/n)")

if (login == 'y'):
    token = input("Enter your token: ")
    try:
        payload = jwt.decode(token, verify=False)
        print("Hello user with the account number {}".format(payload['number']))
    except:
        print("Error")
    amount = input("Enter desired amount: ")
    r = requests.get("http://127.0.0.1:8080/", params={"amount": amount,
                                                       'token': token})
    print("Request method: GET, \Response status_code: {}, Response data: {} ".format(r.status_code, r.text))

elif (login == 'n'):
    number = input("Enter your number: ")
    password = input("Enter your password: ")
    r = requests.post("http://127.0.0.1:8080/", params={
        'number': number, 'password': password})
    print("Request method: POST, \Response status_code: {}, Response data: {} ".format(r.status_code, r.text))
    print("Copy and save your token!")
else:
    print("Wrong action")